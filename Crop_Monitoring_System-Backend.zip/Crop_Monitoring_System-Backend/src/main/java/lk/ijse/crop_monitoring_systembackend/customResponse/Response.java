package lk.ijse.crop_monitoring_systembackend.customResponse;

public interface Response {
}
