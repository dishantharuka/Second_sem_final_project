package lk.ijse.crop_monitoring_systembackend.exception;

public class NotFoundException extends RuntimeException {
    public NotFoundException() {
    }

    public NotFoundException(String message) {
    }

    public NotFoundException(String message, Throwable cause) {
    }
}
