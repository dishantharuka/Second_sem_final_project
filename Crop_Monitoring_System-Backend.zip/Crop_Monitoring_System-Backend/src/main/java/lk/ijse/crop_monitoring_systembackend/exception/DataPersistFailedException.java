package lk.ijse.crop_monitoring_systembackend.exception;

public class DataPersistFailedException extends RuntimeException {
    public DataPersistFailedException() {
    }

    public DataPersistFailedException(String message) {
    }

    public DataPersistFailedException(String message, Throwable cause) {
    }
}