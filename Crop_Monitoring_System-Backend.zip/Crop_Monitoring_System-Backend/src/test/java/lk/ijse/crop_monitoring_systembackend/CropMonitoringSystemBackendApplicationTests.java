package lk.ijse.crop_monitoring_systembackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CropMonitoringSystemBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
